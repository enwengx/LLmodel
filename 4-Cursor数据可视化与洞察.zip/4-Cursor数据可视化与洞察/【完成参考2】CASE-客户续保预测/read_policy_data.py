import pandas as pd

# 读取 policy_data.xlsx 文件的前5行数据
file_path = 'policy_data.xlsx'
df = pd.read_excel(file_path)

# 设置显示所有列
pd.set_option('display.max_columns', None)

print("前5行数据：")
print(df.head(5))

# 打印所有字段名（列名）
print("\n数据字段（列名）：")
print(df.columns.tolist())  # 输出所有字段名 