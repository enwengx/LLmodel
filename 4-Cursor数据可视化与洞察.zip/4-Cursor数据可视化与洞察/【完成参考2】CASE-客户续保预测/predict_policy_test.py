import pandas as pd
import joblib
import numpy as np

# 1. 加载模型、标准化器和特征名
model = joblib.load('logistic_regression_renewal_model.joblib')
scaler = joblib.load('scaler.joblib')
feature_names = joblib.load('feature_names.joblib')

# 2. 读取测试数据
file_path = 'policy_test.xlsx'
df = pd.read_excel(file_path)

# 3. 数据预处理（与训练时保持一致）
drop_cols = ['policy_id', 'policy_start_date', 'policy_end_date', 'policy_type']
df = df.drop(columns=drop_cols, errors='ignore')

# 填充缺失值（数值型用均值，类别型用众数）
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())

# 类别变量编码（与训练时一致，简单用LabelEncoder，假设测试集类别未超出训练集）
from sklearn.preprocessing import LabelEncoder
cat_cols = df.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])

# 只保留训练时的特征列
X = df[feature_names]

# 标准化
X_scaled = scaler.transform(X)

# 4. 预测
pred = model.predict(X_scaled)
pred_prob = model.predict_proba(X_scaled)[:,1]

# 5. 输出预测结果
result = pd.DataFrame({
    '预测是否续保': pred,
    '续保概率': pred_prob
})
print('policy_test.xlsx 预测结果：')
print(result)

# 可选：保存结果到Excel
result.to_excel('policy_test_predict_result.xlsx', index=False)
print('预测结果已保存为 policy_test_predict_result.xlsx') 