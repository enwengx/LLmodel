import pandas as pd
import matplotlib.pyplot as plt

# 读取数据
file_path = 'policy_data.xlsx'
df = pd.read_excel(file_path)

# 设置显示所有列
pd.set_option('display.max_columns', None)

# 1. 数据基本信息
print('数据基本信息：')
print(f'总行数: {df.shape[0]}，总列数: {df.shape[1]}')
print('字段类型：')
print(df.dtypes)
print('\n')

# 2. 缺失值统计
print('各字段缺失值统计：')
print(df.isnull().sum())
print('\n')

# 3. 数值型字段描述性统计
print('数值型字段描述性统计：')
print(df.describe())
print('\n')

# 4. 类别型字段分布
cat_cols = df.select_dtypes(include=['object']).columns
print('类别型字段分布：')
for col in cat_cols:
    print(f'字段：{col}')
    print(df[col].value_counts(dropna=False))
    print('-'*30)

# 5. 续保率统计
print('续保情况统计（renewal 字段）：')
print(df['renewal'].value_counts(normalize=True))

# ================= 可视化部分 =================
import matplotlib.font_manager as fm
# 设置中文字体，防止中文乱码（如有需要可根据本地字体调整）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

# 1. 数值型字段直方图
num_cols = df.select_dtypes(include=['number']).columns
for col in num_cols:
    plt.figure(figsize=(6,4))
    df[col].hist(bins=30, color='skyblue', edgecolor='black')
    plt.title(f'{col} 分布直方图')
    plt.xlabel(col)
    plt.ylabel('频数')
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(f'{col}_hist.png')  # 保存图片
    plt.close()

# 2. 类别型字段条形图（只画前10类）
for col in cat_cols:
    plt.figure(figsize=(7,4))
    df[col].value_counts(dropna=False).head(10).plot(kind='bar', color='orange', edgecolor='black')
    plt.title(f'{col} 前10类别分布')
    plt.xlabel(col)
    plt.ylabel('数量')
    plt.tight_layout()
    plt.savefig(f'{col}_bar.png')
    plt.close()

# 3. 续保率饼图
plt.figure(figsize=(5,5))
df['renewal'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['#66b3ff','#ff9999'])
plt.title('续保情况分布')
plt.ylabel('')
plt.tight_layout()
plt.savefig('renewal_pie.png')
plt.close()

# 提示用户图片已保存
print('\n所有可视化图表已保存为 PNG 文件。') 