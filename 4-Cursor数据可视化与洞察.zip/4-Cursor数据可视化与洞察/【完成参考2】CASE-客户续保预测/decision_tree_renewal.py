import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree
from sklearn.preprocessing import LabelEncoder
import joblib
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# 设置matplotlib中文字体，防止中文乱码
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
file_path = 'policy_data.xlsx'
df = pd.read_excel(file_path)

# 删除与预测无关或唯一标识的字段
drop_cols = ['policy_id', 'policy_start_date', 'policy_end_date', 'policy_type']
df = df.drop(columns=drop_cols, errors='ignore')

# 续保字段编码（Yes=1, 其他=0）
df['renewal'] = (df['renewal'] == 'Yes').astype(int)

# 填充缺失值（数值型用均值，类别型用众数）
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())

# 类别变量编码
cat_cols = df.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])

# 特征与标签
X = df.drop('renewal', axis=1)
y = df['renewal']

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练决策树模型（深度为4）
dt = DecisionTreeClassifier(max_depth=4, random_state=42)
dt.fit(X_train, y_train)

# 打印决策树结构（文本形式）
print('决策树结构如下：')
print(export_text(dt, feature_names=list(X.columns), show_weights=True))

# 可视化决策树并保存
plt.figure(figsize=(20,10))
plot_tree(dt, feature_names=X.columns, class_names=['不续保','续保'], filled=True, rounded=True, fontsize=12)
plt.title('决策树可视化（续保预测，深度=4）')
plt.tight_layout()
plt.savefig('decision_tree_renewal.png')
plt.show()
print('决策树可视化图已保存为 decision_tree_renewal.png')

# ================== 模型验证 ==================

# 训练集预测与评估
train_pred = dt.predict(X_train)
train_acc = accuracy_score(y_train, train_pred)
print(f'训练集准确率: {train_acc:.4f}')

# 测试集预测与评估
test_pred = dt.predict(X_test)
test_acc = accuracy_score(y_test, test_pred)
print(f'测试集准确率: {test_acc:.4f}')

# 混淆矩阵和分类报告
print('\n测试集混淆矩阵：')
print(confusion_matrix(y_test, test_pred))
print('\n测试集分类报告：')
print(classification_report(y_test, test_pred, target_names=['不续保','续保'])) 