import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import joblib

# 设置matplotlib中文字体，防止中文乱码
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
file_path = 'policy_data.xlsx'
df = pd.read_excel(file_path)

# 删除与预测无关或唯一标识的字段
drop_cols = ['policy_id', 'policy_start_date', 'policy_end_date', 'policy_type']
df = df.drop(columns=drop_cols, errors='ignore')

# 续保字段编码（Yes=1, 其他=0）
df['renewal'] = (df['renewal'] == 'Yes').astype(int)

# 填充缺失值（数值型用均值，类别型用众数）
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())

# 对所有类别型特征进行0-1编码（独热编码）
df_dummies = pd.get_dummies(df, drop_first=True)

# 特征与标签
X = df_dummies.drop('renewal', axis=1)
y = df_dummies['renewal']

# 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 训练逻辑回归模型
lr = LogisticRegression(max_iter=1000)
lr.fit(X_train, y_train)

# 打印逻辑回归系数及对应特征名
coef = lr.coef_[0]
features = X.columns
print('逻辑回归系数（特征名 : 系数）：')
for f, c in zip(features, coef):
    print(f'{f} : {c:.4f}')

# 可视化所有特征的系数（显示正负）
plt.figure(figsize=(12, max(6, len(features)//3)))
colors = ['red' if c < 0 else 'green' for c in coef]
plt.barh(features, coef, color=colors)
plt.xlabel('逻辑回归系数')
plt.title('各特征（0-1编码）对续保预测的影响（正负）')
plt.grid(axis='x', alpha=0.3)
plt.tight_layout()
plt.savefig('logistic_regression_01_coefficients.png')
plt.show()

print('\n逻辑回归系数可视化图已保存为 logistic_regression_01_coefficients.png')

# 保存模型、标准化器和特征名
joblib.dump(lr, 'logistic_regression_01_model.joblib')
joblib.dump(scaler, 'scaler_01.joblib')
joblib.dump(list(X.columns), 'feature_names_01.joblib')
print('模型、标准化器和特征名已保存。') 